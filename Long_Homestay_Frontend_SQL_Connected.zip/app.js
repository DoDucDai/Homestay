/*
 * StayNest Frontend - Phùng Lê Bảo Long
 * Tích hợp kết nối trực tiếp với Database/Backend SQL Server HomestayDB.
 * Đã hỗ trợ cả DEMO_MODE và API kết nối Backend (C# / Node.js / Java).
 */

// Đổi DEMO_MODE = false khi Đức Đại chạy Backend API
const DEMO_MODE = true; 
const API_BASE = "http://localhost:5000/api"; // Endpoint Backend nối SQL Server

const $ = (id) => document.getElementById(id);
const today = new Date().toISOString().slice(0,10);

let customers = [];
let rooms = [];
let bookings = [];
let toastTimer;

// Dữ liệu mẫu khớp 100% với file seed_data.sql trong SQL Server HomestayDB
const demoSeed = {
  customers: [
    { customer_id: 1, full_name: "Nguyễn Văn An", cccd: "001099001234", phone: "0901234567", email: "an@email.com", address: "Hà Nội", created_at: today },
    { customer_id: 2, full_name: "Trần Thị Bình", cccd: "001099005678", phone: "0912345678", email: "binh@email.com", address: "TP. Hồ Chí Minh", created_at: today },
    { customer_id: 3, full_name: "Lê Hoàng Cường", cccd: "001099009012", phone: "0923456789", email: "cuong@email.com", address: "Đà Nẵng", created_at: today },
    { customer_id: 4, full_name: "Phạm Thị Dung", cccd: "001099003456", phone: "0934567890", email: "dung@email.com", address: "Huế", created_at: today },
    { customer_id: 5, full_name: "Hoàng Minh Đức", cccd: "001099007890", phone: "0945678901", email: "duc@email.com", address: "Nha Trang", created_at: today }
  ],
  rooms: [
    { room_id: 1, room_code: "P101", room_name: "Phòng Đơn Tầng 1", room_type: "Single", price: 300000, status: "Trống" },
    { room_id: 2, room_code: "P102", room_name: "Phòng Đôi Tầng 1", room_type: "Double", price: 500000, status: "Trống" },
    { room_id: 3, room_code: "P201", room_name: "Phòng VIP Tầng 2", room_type: "VIP", price: 900000, status: "Trống" },
    { room_id: 4, room_code: "P202", room_name: "Phòng Gia Đình Tầng 2", room_type: "Family", price: 1200000, status: "Trống" },
    { room_id: 5, room_code: "P301", room_name: "Phòng Đơn Tầng 3", room_type: "Single", price: 350000, status: "Đang sử dụng" },
    { room_id: 6, room_code: "P302", room_name: "Phòng Đôi Tầng 3", room_type: "Double", price: 550000, status: "Bảo trì" }
  ],
  bookings: [
    { booking_id: 1, customer_id: 1, room_id: 1, checkin_date: "2026-09-10", checkout_date: "2026-09-13", status: "CheckedOut", note: "Khách đã thanh toán" },
    { booking_id: 2, customer_id: 2, room_id: 2, checkin_date: "2026-09-12", checkout_date: "2026-09-15", status: "CheckedIn", note: "" },
    { booking_id: 3, customer_id: 3, room_id: 5, checkin_date: "2026-09-13", checkout_date: "2026-09-16", status: "CheckedIn", note: "Yêu cầu phòng im lặng" },
    { booking_id: 4, customer_id: 4, room_id: 3, checkin_date: "2026-09-15", checkout_date: "2026-09-18", status: "Confirmed", note: "Đặt phòng VIP" },
    { booking_id: 5, customer_id: 5, room_id: 4, checkin_date: "2026-09-16", checkout_date: "2026-09-20", status: "Confirmed", note: "Gia đình 4 người" }
  ]
};

function addDays(date, n) {
  const d = new Date(date + "T12:00:00");
  d.setDate(d.getDate() + n);
  return d.toISOString().slice(0, 10);
}

function escapeHTML(s = "") {
  return String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

async function request(path, options = {}) {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json", ...(options.headers || {}) },
    ...options
  });
  if (!res.ok) {
    let msg = `Lỗi máy chủ (${res.status})`;
    try { const data = await res.json(); msg = data.message || msg; } catch {}
    throw new Error(msg);
  }
  if (res.status === 204) return null;
  return res.json();
}

function notify(message) {
  const el = $("toast");
  el.textContent = message;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2800);
}

function initials(name = "") {
  return name.split(/\s+/).filter(Boolean).slice(-2).map(x => x[0]).join("").toUpperCase();
}

function customerById(id) {
  return customers.find(c => Number(c.customer_id) === Number(id));
}

function roomById(id) {
  return rooms.find(r => Number(r.room_id) === Number(id));
}

function dateText(s) {
  if (!s) return "—";
  const d = new Date(s + "T00:00:00");
  return d.toLocaleDateString("vi-VN");
}

function nights(b) {
  if (!b.checkin_date || !b.checkout_date) return 0;
  return Math.max(0, Math.round((new Date(b.checkout_date + "T00:00:00") - new Date(b.checkin_date + "T00:00:00")) / 86400000));
}

async function loadData() {
  if (DEMO_MODE) {
    customers = JSON.parse(JSON.stringify(demoSeed.customers));
    rooms = JSON.parse(JSON.stringify(demoSeed.rooms));
    bookings = JSON.parse(JSON.stringify(demoSeed.bookings));
    $("mode-label").textContent = "Chế độ Test (Local Database Seed)";
    return;
  }
  $("mode-label").textContent = "Đã kết nối Backend (HomestayDB)";
  [customers, rooms, bookings] = await Promise.all([
    request("/customers"),
    request("/rooms"),
    request("/bookings")
  ]);
}

function renderCustomers() {
  const q = $("customer-search").value.trim().toLocaleLowerCase("vi");
  const rows = customers.filter(c => 
    [c.customer_id, c.full_name, c.cccd, c.phone, c.email].some(v => String(v || "").toLocaleLowerCase("vi").includes(q))
  );

  $("customer-rows").innerHTML = rows.length ? rows.map(c => `
    <tr>
      <td>KH${String(c.customer_id).padStart(3, "0")}</td>
      <td class="name-cell"><span class="mini-avatar">${escapeHTML(initials(c.full_name || "?"))}</span>${escapeHTML(c.full_name)}</td>
      <td>${escapeHTML(c.cccd || "—")}</td>
      <td>${escapeHTML(c.phone)}</td>
      <td>${escapeHTML(c.email || "—")}</td>
      <td>${dateText(c.created_at || today)}</td>
      <td>
        <div class="table-actions">
          <button class="text-btn" data-edit-customer="${c.customer_id}">Sửa</button>
          <button class="text-btn danger" data-delete-customer="${c.customer_id}">Xóa</button>
        </div>
      </td>
    </tr>
  `).join("") : `<tr><td colspan="7" class="empty">Không tìm thấy khách hàng phù hợp.</td></tr>`;

  $("customer-total").textContent = customers.length;
  const active = bookings.filter(b => (b.status === "Confirmed" || b.status === "CheckedIn") && b.checkin_date <= today && b.checkout_date > today).length;
  $("customer-staying").textContent = active;
  $("booking-total").textContent = bookings.length;
  $("customer-count").textContent = `${rows.length} khách hàng`;
}

function getStatusBadge(status) {
  switch (status) {
    case "Confirmed": return '<span class="pill confirmed">Đã xác nhận</span>';
    case "CheckedIn": return '<span class="pill confirmed" style="background:#e3f2fd;color:#1976d2;">Đang lưu trú</span>';
    case "CheckedOut": return '<span class="pill" style="background:#e8f5e9;color:#2e7d32;">Đã trả phòng</span>';
    case "Cancelled": return '<span class="pill cancelled">Đã hủy</span>';
    default: return `<span class="pill">${escapeHTML(status)}</span>`;
  }
}

function renderBookings() {
  const q = $("booking-search").value.trim().toLocaleLowerCase("vi");
  const filter = $("booking-filter").value;
  
  const rows = bookings.filter(b => {
    const c = customerById(b.customer_id);
    const r = roomById(b.room_id);
    const matchFilter = !filter || b.status.toUpperCase() === filter.toUpperCase();
    const matchSearch = [b.booking_id, c?.full_name, r?.room_code, r?.room_name].some(v => String(v || "").toLocaleLowerCase("vi").includes(q));
    return matchFilter && matchSearch;
  });

  $("booking-rows").innerHTML = rows.length ? rows.map(b => {
    const c = customerById(b.customer_id);
    const r = roomById(b.room_id);
    const isCancelled = b.status === "Cancelled";
    
    return `
      <tr>
        <td>BK${String(b.booking_id).padStart(3, "0")}</td>
        <td class="name-cell">${escapeHTML(c?.full_name || "Khách không tồn tại")}</td>
        <td>${escapeHTML(r ? `${r.room_code} (${r.room_name})` : "—")}</td>
        <td>${dateText(b.checkin_date)}</td>
        <td>${dateText(b.checkout_date)}</td>
        <td>${nights(b)}</td>
        <td>${getStatusBadge(b.status)}</td>
        <td>${isCancelled || b.status === "CheckedOut" ? "" : `<button class="text-btn danger" data-cancel-booking="${b.booking_id}">Hủy</button>`}</td>
      </tr>
    `;
  }).join("") : `<tr><td colspan="8" class="empty">Chưa có booking phù hợp.</td></tr>`;

  $("booking-total-2").textContent = bookings.length;
  $("booking-confirmed").textContent = bookings.filter(b => b.status === "Confirmed" || b.status === "CheckedIn").length;
  $("booking-cancelled").textContent = bookings.filter(b => b.status === "Cancelled").length;
  $("booking-count").textContent = `${rows.length} booking`;
}

function renderAll() {
  renderCustomers();
  renderBookings();
}

function openModal(id) { $(id).classList.add("open"); }
function closeModals() { document.querySelectorAll(".modal-backdrop").forEach(m => m.classList.remove("open")); }
function customerFormError(msg) { $("customer-error").textContent = msg; }
function bookingFormError(msg) { $("booking-error").textContent = msg; }

function openCustomer(c = null) {
  $("customer-form").reset();
  customerFormError("");
  $("customer-id").value = c?.customer_id || "";
  $("customer-modal-title").textContent = c ? "Cập nhật khách hàng" : "Thêm khách hàng";
  
  if (c) {
    $("customer-name").value = c.full_name || "";
    const cccdEl = $("customer-cccd");
    if (cccdEl) cccdEl.value = c.cccd || "";
    $("customer-phone").value = c.phone || "";
    $("customer-email").value = c.email || "";
    $("customer-address").value = c.address || "";
  }
  openModal("customer-modal");
}

function fillBookingSelects() {
  $("booking-customer").innerHTML = '<option value="">Chọn khách hàng (Database Customers)</option>' + 
    customers.map(c => `<option value="${c.customer_id}">${escapeHTML(c.full_name)} — CCCD: ${escapeHTML(c.cccd || "N/A")} — SĐT: ${escapeHTML(c.phone)}</option>`).join("");
    
  $("booking-room").innerHTML = '<option value="">Chọn phòng (Database Rooms)</option>' + 
    rooms.filter(r => r.status === "Trống" || r.status === "AVAILABLE" || DEMO_MODE).map(r => `
      <option value="${r.room_id}">${escapeHTML(r.room_code)} - ${escapeHTML(r.room_name)} (${escapeHTML(r.room_type)}) · ${Number(r.price || 0).toLocaleString("vi-VN")}đ/đêm</option>
    `).join("");
}

function openBooking() {
  bookingFormError("");
  $("booking-form").reset();
  fillBookingSelects();
  $("checkin-date").min = today;
  $("checkout-date").min = addDays(today, 1);
  $("night-count").textContent = "—";
  openModal("booking-modal");
}

function updateNights() {
  const a = $("checkin-date").value;
  const b = $("checkout-date").value;
  const n = Math.round((new Date(b + "T00:00:00") - new Date(a + "T00:00:00")) / 86400000);
  $("night-count").textContent = a && b && n > 0 ? `${n} đêm` : "—";
  if (a) $("checkout-date").min = addDays(a, 1);
}

function phoneValid(phone) {
  return /^(0|\+84)[0-9]{9,10}$/.test(phone.replace(/[\s.-]/g, ""));
}

function emailValid(email) {
  return !email || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

// Navigation Events
document.querySelectorAll(".nav-item").forEach(btn => btn.addEventListener("click", () => {
  document.querySelectorAll(".nav-item").forEach(x => x.classList.remove("active"));
  btn.classList.add("active");
  document.querySelectorAll(".page").forEach(x => x.classList.remove("active"));
  $(`${btn.dataset.page}-page`).classList.add("active");
  $("page-title").textContent = btn.dataset.page === "customers" ? "Quản lý khách hàng" : "Quản lý Booking";
}));

$("add-customer").addEventListener("click", () => openCustomer());
$("add-booking").addEventListener("click", () => {
  if (!customers.length || !rooms.length) {
    notify("Cần có khách hàng và phòng trước khi tạo booking.");
    return;
  }
  openBooking();
});

document.querySelectorAll(".close-modal").forEach(b => b.addEventListener("click", closeModals));
document.querySelectorAll(".modal-backdrop").forEach(m => m.addEventListener("click", e => { if (e.target === m) closeModals(); }));

$("customer-search").addEventListener("input", renderCustomers);
$("booking-search").addEventListener("input", renderBookings);
$("booking-filter").addEventListener("change", renderBookings);

// Table Actions - Customers
$("customer-rows").addEventListener("click", async e => {
  const edit = e.target.closest("[data-edit-customer]");
  const del = e.target.closest("[data-delete-customer]");
  
  if (edit) {
    openCustomer(customerById(edit.dataset.editCustomer));
    return;
  }
  if (del) {
    const id = Number(del.dataset.deleteCustomer);
    if (bookings.some(b => Number(b.customer_id) === id && (b.status === "Confirmed" || b.status === "CheckedIn"))) {
      notify("Khách có booking đang hoạt động nên không thể xóa.");
      return;
    }
    if (!confirm("Bạn có chắc muốn xóa khách hàng này khỏi cơ sở dữ liệu?")) return;
    try {
      if (DEMO_MODE) {
        customers = customers.filter(c => Number(c.customer_id) !== id);
      } else {
        await request(`/customers/${id}`, { method: "DELETE" });
      }
      renderAll();
      notify("Đã xóa khách hàng.");
    } catch (err) { notify(err.message); }
  }
});

// Form Submit - Customer
$("customer-form").addEventListener("submit", async e => {
  e.preventDefault();
  customerFormError("");
  
  const id = $("customer-id").value;
  const full_name = $("customer-name").value.trim();
  const cccd = $("customer-cccd") ? $("customer-cccd").value.trim() : "";
  const phone = $("customer-phone").value.trim();
  const email = $("customer-email").value.trim();
  const address = $("customer-address").value.trim();

  if (!full_name) { customerFormError("Vui lòng nhập họ và tên."); return; }
  if (!cccd) { customerFormError("Vui lòng nhập số CCCD / Passport."); return; }
  if (!phoneValid(phone)) { customerFormError("Số điện thoại chưa hợp lệ (ví dụ 0901234567)."); return; }
  if (!emailValid(email)) { customerFormError("Email chưa đúng định dạng."); return; }

  const duplicatePhone = customers.some(c => c.phone.replace(/\D/g, "") === phone.replace(/\D/g, "") && String(c.customer_id) !== id);
  if (duplicatePhone) { customerFormError("Số điện thoại này đã tồn tại trong DB."); return; }

  const duplicateCCCD = customers.some(c => c.cccd === cccd && String(c.customer_id) !== id);
  if (duplicateCCCD) { customerFormError("Số CCCD này đã tồn tại trong DB."); return; }

  const payload = { full_name, cccd, phone, email, address };

  try {
    if (DEMO_MODE) {
      if (id) {
        const i = customers.findIndex(c => String(c.customer_id) === id);
        customers[i] = { ...customers[i], ...payload };
      } else {
        const newId = Math.max(0, ...customers.map(c => Number(c.customer_id))) + 1;
        customers.unshift({ customer_id: newId, ...payload, created_at: today });
      }
    } else {
      if (id) await request(`/customers/${id}`, { method: "PUT", body: JSON.stringify(payload) });
      else await request("/customers", { method: "POST", body: JSON.stringify(payload) });
    }
    await refreshIfAPI();
    closeModals();
    renderAll();
    notify(id ? "Đã cập nhật thông tin khách hàng vào HomestayDB." : "Đã thêm khách hàng mới vào HomestayDB.");
  } catch (err) { customerFormError(err.message); }
});

$("checkin-date").addEventListener("change", updateNights);
$("checkout-date").addEventListener("change", updateNights);

// Form Submit - Booking
$("booking-form").addEventListener("submit", async e => {
  e.preventDefault();
  bookingFormError("");

  const customer_id = Number($("booking-customer").value);
  const room_id = Number($("booking-room").value);
  const checkin_date = $("checkin-date").value;
  const checkout_date = $("checkout-date").value;

  if (!customer_id || !room_id) { bookingFormError("Vui lòng chọn khách hàng và phòng."); return; }
  if (!checkin_date || !checkout_date || checkin_date < today || checkout_date <= checkin_date) {
    bookingFormError("Ngày nhận phải từ hôm nay và ngày trả phải sau ngày nhận."); return;
  }

  const conflict = bookings.some(b => Number(b.room_id) === room_id && b.status !== "Cancelled" && checkin_date < b.checkout_date && checkout_date > b.checkin_date);
  if (conflict) { bookingFormError("Phòng này đã được đặt trong khoảng thời gian trên! Vui lòng chọn ngày/phòng khác."); return; }

  const payload = { customer_id, room_id, checkin_date, checkout_date, status: "Confirmed", note: "Đặt từ Landing Page" };

  try {
    if (DEMO_MODE) {
      const newId = Math.max(1000, ...bookings.map(b => Number(b.booking_id))) + 1;
      bookings.unshift({ booking_id: newId, ...payload });
    } else {
      await request("/bookings", { method: "POST", body: JSON.stringify(payload) });
    }
    await refreshIfAPI();
    closeModals();
    renderAll();
    notify("Tạo Booking thành công vào HomestayDB!");
  } catch (err) { bookingFormError(err.message); }
});

// Cancel Booking
$("booking-rows").addEventListener("click", async e => {
  const btn = e.target.closest("[data-cancel-booking]");
  if (!btn) return;
  const id = Number(btn.dataset.cancelBooking);
  if (!confirm("Xác nhận hủy booking này?")) return;
  
  try {
    if (DEMO_MODE) {
      const b = bookings.find(x => Number(x.booking_id) === id);
      if (b) b.status = "Cancelled";
    } else {
      await request(`/bookings/${id}/cancel`, { method: "PATCH" });
    }
    await refreshIfAPI();
    renderAll();
    notify("Đã hủy booking.");
  } catch (err) { notify(err.message); }
});

async function refreshIfAPI() { if (!DEMO_MODE) await loadData(); }

(async () => {
  try {
    await loadData();
    renderAll();
  } catch (err) {
    notify("Chưa kết nối API Backend. Hiển thị chế độ dữ liệu HomestayDB mẫu: " + err.message);
  }
})();
