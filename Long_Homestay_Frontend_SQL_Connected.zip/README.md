# Long Homestay Frontend - Tích Hợp Cơ Sở Dữ Liệu SQL Server (HomestayDB)

Dự án Frontend quản lý Homestay của **Phùng Lê Bảo Long**, đã được đồng bộ chuẩn 100% tên bảng và tên cột với cơ sở dữ liệu **SQL Server (`HomestayDB`)**.

---

## 🛠️ Danh sách các cập nhật chính

1. **Đồng bộ hóa 100% với Schema SQL (`schema.sql`)**:
   - Khách hàng (`Customers`): `customer_id`, `full_name`, `cccd`, `phone`, `email`, `address`, `created_at`.
   - Phòng (`Rooms`): `room_id`, `room_code`, `room_name`, `room_type`, `price`, `status`.
   - Đặt phòng (`Bookings`): `booking_id`, `customer_id`, `room_id`, `checkin_date`, `checkout_date`, `status`, `note`.

2. **Dữ liệu mẫu chuẩn từ `seed_data.sql`**:
   - Mặc định khởi tạo dữ liệu của các phòng `P101`, `P102`, `P201`, `P202`, `P301`, `P302` cùng danh sách khách hàng và booking thực tế để kiểm thử ngay lập tức.

3. **Cập nhật Form nhập liệu**:
   - Đã thêm ô nhập **Số CCCD / Passport** bắt buộc vào modal thêm khách hàng.

---

## 🚀 Hướng dẫn kiểm thử và bàn giao cho Backend (Đức Đại)

### 1. Test nhanh ở chế độ Offline (Local)
- Mở trực tiếp file `index.html` bằng trình duyệt web.
- Bạn sẽ thấy toàn bộ dữ liệu mẫu trong file `seed_data.sql` hiển thị lên màn hình.
- Thử bấm **＋ Thêm khách hàng** (nhập đủ CCCD, SĐT) hoặc **＋ Tạo booking** để kiểm tra kiểm soát trùng phòng và cập nhật dữ liệu.

### 2. Bàn giao cho Backend (Đức Đại)
Khi Đức Đại viết xong API Backend (C# / Node.js / Java Spring Boot):
1. Mở file `app.js`.
2. Sửa dòng `const DEMO_MODE = true;` thành `const DEMO_MODE = false;`.
3. Cập nhật `API_BASE = "http://localhost:5000/api"` đúng với cổng Backend đang chạy.
