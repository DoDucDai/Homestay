/* User-supplied AI posters. Show the room scenes; prices remain database-owned. */
const RoomPhotos = (() => {
    const landscape = [[8,590,220,155],[241,590,219,155],[466,590,209,155],[685,590,211,155],[910,590,230,155]];
    const cream = [[7,660,172,374],[187,660,169,374],[365,660,167,374],[542,660,164,374],[720,660,166,374]];
    const blue = [[14,817,164,261],[193,817,158,261],[370,817,158,261],[547,817,160,261],[722,817,158,261]];
    const posters = {
        '101': [1152,925,[8,210,895,310],landscape],
        '102': [1152,925,[8,210,895,310],landscape],
        '103': [1152,925,[8,210,895,310],landscape],
        '201': [1152,925,[8,210,895,310],landscape],
        '202': [896,1200,[8,165,680,423],cream],
        '301': [896,1200,[8,145,680,443],cream],
        '401': [896,1200,[8,164,680,424],[[6,660,211,374],[231,660,212,374],[454,660,210,374],[680,660,210,374]]],
        '402': [896,1200,[8,185,680,460],[[8,733,279,303],[310,733,130,303],[451,733,135,303],[609,733,132,303],[750,733,138,303]]],
        '403': [1200,896,[12,215,986,280],[[14,575,221,220],[255,575,214,220],[491,575,218,220],[730,575,219,220],[969,575,220,220]]],
        '404': [896,1200,[12,175,695,557],blue],
        '405': [896,1200,[12,175,695,557],blue],
        '406': [768,1376,[12,315,740,620],[[14,1020,135,230],[163,1020,136,230],[313,1020,137,230],[462,1020,141,230],[620,1020,133,230]]],
        '407': [896,1200,[14,345,866,430],[[16,859,157,205],[194,859,151,205],[371,859,154,205],[546,859,155,205],[721,859,156,205]]]
    };
    function lookup(room) {
        const match = /^(?:DEMO-)?P(\d{3})$/.exec(String(room?.roomCode || '').toUpperCase());
        const number = match?.[1], poster = posters[number];
        return poster ? {number, width:poster[0], height:poster[1], scenes:[poster[2],...poster[3]]} : null;
    }
    function view(photo, scene, label) {
        const ns = 'http://www.w3.org/2000/svg';
        const svg = document.createElementNS(ns,'svg');
        svg.setAttribute('viewBox',scene.join(' '));
        svg.setAttribute('preserveAspectRatio','xMidYMid slice');
        svg.setAttribute('role','img');svg.setAttribute('aria-label',label);
        svg.classList.add('room-photo-visual');
        const image = document.createElementNS(ns,'image');
        image.setAttribute('href','../css/images/rooms/room-'+photo.number+'.webp');
        image.setAttribute('width',String(photo.width));image.setAttribute('height',String(photo.height));
        svg.append(image);return svg;
    }
    function create(room, {gallery=false}={}) {
        const photo = lookup(room);if(!photo)return null;
        const figure = document.createElement(gallery?'figure':'span');figure.className='room-photo';
        const label='Ảnh minh họa AI · '+room.roomCode;
        const main=view(photo,photo.scenes[0],label);figure.append(main);
        const credit=document.createElement(gallery?'figcaption':'span');credit.className='room-photo-credit';
        credit.textContent='Ảnh minh họa AI';
        if(gallery) {
            figure.classList.add('room-photo-gallery');
            const choices=document.createElement('div');choices.className='room-photo-choices';
            choices.setAttribute('role','group');choices.setAttribute('aria-label','Các góc nhìn phòng '+room.roomCode);
            photo.scenes.forEach((scene,index)=>{
                const button=document.createElement('button');button.type='button';
                button.className='room-photo-choice';button.setAttribute('aria-label','Xem góc nhìn '+(index+1)+' của phòng '+room.roomCode);
                button.setAttribute('aria-pressed',String(index===0));
                const thumb=view(photo,scene,'');thumb.setAttribute('aria-hidden','true');thumb.removeAttribute('role');
                button.append(thumb);button.addEventListener('click',()=>{
                    main.setAttribute('viewBox',scene.join(' '));
                    main.setAttribute('aria-label',label+' · góc nhìn '+(index+1));
                    for(const choice of choices.children)choice.setAttribute('aria-pressed',String(choice===button));
                    credit.textContent='Ảnh minh họa AI · Góc nhìn '+(index+1)+' / '+photo.scenes.length;
                });choices.append(button);
            });figure.append(choices);
        }
        figure.append(credit);return figure;
    }
    return {lookup,create};
})();
