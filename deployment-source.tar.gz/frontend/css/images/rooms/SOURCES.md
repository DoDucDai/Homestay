# Room illustrations

13 unique AI-generated room posters supplied by the user on 2026-11-03 from
Downloads `file` and `file (1)`. Six duplicate files were omitted by SHA-256.
`sources.json` records the original filenames and room numbers printed on them.

WebP copies preserve the supplied poster content. Original PNG files remain in
Downloads. The UI uses SVG view boxes to show only the interior photographs,
without the posters' generated text, prices or claims about amenities.

Room numbers map to matching `Pxxx` and `DEMO-Pxxx` codes. Unknown numbers keep
the existing placeholder instead of borrowing an unrelated room's illustration.
These are labelled AI illustrations; booking prices and availability come from
the application database.
