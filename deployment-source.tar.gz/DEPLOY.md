# Deploy Homestay + Mochi bằng Docker

## Phương án demo miễn phí

Chạy một **Render Web Service (Docker, Free)** chứa frontend, Java 17 và Python AI RAG. Java phục vụ web/API trên cùng tên miền; Python chỉ nghe loopback 8091 bên trong container. Không cần tách frontend sang Vercel để bản này hoạt động.

Phần dữ liệu phòng, khách, booking và hóa đơn vẫn cần **SQL Server online hoặc Azure SQL Database**. Qdrant là lựa chọn mở rộng cho tìm kiếm vector; dự án hiện chưa có tích hợp embedding/Qdrant, không thể thay SQL Server chỉ bằng cách đổi URL kết nối.

Render Free không có persistent disk; file SQLite sẽ mất khi service bị tạo lại. Container tự nạp bộ 101 tài liệu đã đóng gói vào SQLite mới, cùng tài liệu mặc định. Chỉnh sửa tài liệu và yêu cầu Support phát sinh trên bản demo không được giữ bền vững. SQL Server online là nơi lưu dữ liệu nghiệp vụ, không nằm trong filesystem tạm này. Xem [giới hạn Render Free](https://render.com/docs/free).

## 1. Chuẩn bị SQL Server online

### Không dùng được Azure miễn phí

Có thể thử **Render + SQL Server của Somee** để giữ kiến trúc hiện tại. Somee công bố gói miễn phí có 1 database MS SQL, 30 MB dữ liệu và 30 MB log, không yêu cầu thông tin thẻ khi đăng ký. Đây là hạn mức nhỏ cho demo, không phải lựa chọn đã được kiểm chứng kết nối với ứng dụng này. Xem [gói Somee](https://somee.com/freeaspnethosting.aspx) và [hướng dẫn kết nối SQL từ xa](https://www.somee.com/MSSQLHosting.aspx).

1. Tạo gói miễn phí trên Somee và database SQL trong control panel. Lấy đúng Server Name, Database Name và SQL Login; không dùng tài khoản đăng nhập website Somee làm SQL Login.
2. Kết nối bằng SSMS tới database được cấp, rồi nhập script schema/data của database demo. Không chạy `CREATE DATABASE HomestayDB` nếu hosting đã tạo database với tên khác. Chỉ nhập vào database đã chọn.
3. Trên Render đặt `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASSWORD` theo thông tin Somee; giữ `DB_ENCRYPT=true` và `DB_TRUST_SERVER_CERTIFICATE=false`.
4. Kiểm tra kết nối từ Render và chuỗi chứng chỉ SQL. Tài liệu nhà cung cấp xác nhận truy cập SQL từ xa, nhưng chưa có database Somee cụ thể để thử JDBC/TLS trong dự án này. Nếu gặp lỗi chứng chỉ, cần xác minh chứng chỉ/CA hoặc hỏi nhà cung cấp; không coi việc bỏ kiểm tra chứng chỉ là triển khai prod đã đạt.
5. Kiểm tra hạn mức và quy tắc duy trì hoạt động của gói miễn phí trong control panel. Bản Docker Render vẫn có giới hạn SQLite đã nêu phía trên.

Hai hướng khác nếu Somee không phù hợp:

- **Demo bằng link tạm từ máy hiện tại:** [Cloudflare Quick Tunnel](https://developers.cloudflare.com/tunnel/get-started/quick-tunnels/) đưa dịch vụ local ra URL HTTPS tạm, không yêu cầu tài khoản/domain. Máy phải bật và các dịch vụ local phải chạy. Đây là chia sẻ bản demo, không phải host độc lập; URL thay đổi giữa các lần mở và không có bảo đảm uptime. Không cần di chuyển SQL Server hay SQLite để dùng cách này. Chưa tự bật tunnel hoặc công khai dịch vụ trong công việc hiện tại.
- **Nếu được phép đổi SQL Server:** [Neon có gói PostgreSQL miễn phí](https://neon.com/blog/neon-free-plan-1-gb-per-project). Có thể giữ app trên Render nhưng phải chuyển schema, driver và các câu T-SQL, kiểm tra lại giao dịch/khóa và chuyển dữ liệu. Không thể chỉ thay connection string. Bản mã hiện tại chưa hỗ trợ PostgreSQL; chưa thực hiện migration này.

### Nếu dùng Azure SQL

Nếu đủ điều kiện tài khoản, có thể dùng [Azure SQL Database free offer](https://learn.microsoft.com/azure/azure-sql/database/free-offer-faq). Mức miễn phí theo tháng hiện gồm 100.000 vCore-seconds, 32 GB dữ liệu và 32 GB backup. Chọn **Auto-pause until next month** để database tạm dừng khi hết hạn mức, thay vì tự tiếp tục tính phí. Kiểm tra điều kiện subscription và chi phí hiển thị trước khi tạo tài nguyên.

1. Tạo Azure SQL Database theo free offer, đặt tên database, server và thông tin đăng nhập SQL.
2. Ghi lại hostname dạng `ten-server.database.windows.net`, database name, SQL username và password. Không đặt chúng trong frontend hoặc Git.
3. Nhập schema và dữ liệu demo đã chọn từ SQL Server hiện tại. Với SSMS, dùng **Tasks → Generate Scripts**, chọn **Schema and data**, engine đích **Microsoft Azure SQL Database**, **Script USE DATABASE = False**, chỉ tạo các đối tượng trong database đích đã mở. Xem [Generate Scripts](https://learn.microsoft.com/en-us/ssms/scripting/generate-and-publish-scripts-wizard).
4. Không chạy nguyên xi `database/schema.sql` vào Azure SQL: file local có `CREATE DATABASE` và `USE`. Xuất từ database đang chạy giúp mang đủ các cột và chỉ mục sau migration 001–007. Chỉ mang dữ liệu phù hợp để demo; giữ script xuất ngoài repository.
5. Bản `prod` của ứng dụng yêu cầu mật khẩu Users đã băm đúng định dạng và từ chối khởi động nếu bất kỳ tài khoản nào vẫn dùng mật khẩu demo `123456`. Đổi các mật khẩu demo trên hệ thống local trước khi xuất, hoặc chuẩn bị tài khoản đích đúng quy trình. Không tắt chốt này để đưa bản demo lên Internet.
6. Cho phép các địa chỉ outbound của service Render kết nối tới SQL Server qua firewall của database. Lấy địa chỉ từ Render Dashboard; không dùng `localhost` hoặc `host.docker.internal` cho database trên cloud.

Docker này không tự tạo tài nguyên Azure, không chạy migration phá dữ liệu và không tự sao chép database local lên Internet.

`ai-rag/knowledge/published.json` là bundle 101 tài liệu đã đối chiếu với danh mục local lúc 02/11/2026. Nếu chuyển lên database có danh mục khác, xuất danh mục mới theo `ai-rag/knowledge/README.md` rồi cập nhật bundle trước khi build:

```powershell
python ai-rag/import-knowledge.py --catalog ai-rag/data/catalog-rag-snapshot.json --export-bundle ai-rag/knowledge/published.json
```

Lệnh này sinh bundle/markdown để review, không sửa SQLite nếu không có `--apply`. Các chỉnh sửa tài liệu thực hiện riêng qua trang admin không tự xuất vào bundle; muốn giữ chúng trên bản demo không có disk cần bổ sung lại vào nguồn đã duyệt trước khi đóng gói.

## 2. Deploy lên Render

Các file `Dockerfile` và `render.yaml` nằm tại root repo **Homestay**. Đưa thay đổi mã nguồn lên repository của bạn, giữ `.env` và `.env.docker` ở máy.

1. Trên Render, tạo **Blueprint** từ repository và chọn `render.yaml`. Hoặc tạo **Web Service**, chọn runtime **Docker**, Dockerfile `./Dockerfile`, context `.` và plan **Free**. Nếu repository của bạn có thư mục cha chứa Homestay thì đặt Root Directory là `Homestay`.
2. Nhập biến môi trường dưới đây. `render.yaml` đã đặt profile, TLS, đường dẫn RAG và model; các giá trị bí mật được nhập trong Render Dashboard.

| Biến | Giá trị |
| --- | --- |
| `DB_HOST` | Host SQL Server/Azure SQL online |
| `DB_PORT` | `1433` |
| `DB_NAME` | Tên database đã nhập schema/data |
| `DB_USER` | SQL username |
| `DB_PASSWORD` | SQL password, nhập như secret |
| `OPENROUTER_API_KEY` | API key của bạn, nhập như secret |
| `OPENROUTER_MODEL` | `openrouter/free` |
| `SPRING_PROFILES_ACTIVE` | `prod` |
| `COOKIE_SECURE` | `true` |
| `DB_ENCRYPT` | `true` |
| `DB_TRUST_SERVER_CERTIFICATE` | `false` |
| `AI_RAG_DB_PATH` | `/tmp/homestay/assistant.sqlite3` cho Render Free |

3. Để Docker Command mặc định. Entrypoint lấy `PORT` Render cấp, bind Java vào `0.0.0.0`, đặt callback Python về đúng cổng Java và giám sát cả hai process. Nếu một process dừng, process còn lại cũng được dừng để nền tảng khởi động lại đồng bộ.
4. Health Check Path: **`/api/health`**. Endpoint chỉ báo sẵn sàng sau các kiểm tra startup của Java và không ping SQL liên tục. Docker healthcheck còn kiểm tra process RAG ở loopback; không xác minh quota hoặc độ đúng câu trả lời model.
5. Khi deploy xong, mở `https://ten-service.onrender.com/`, đăng nhập bằng tài khoản đã có trong database, rồi kiểm tra Đặt phòng, Tài liệu RAG và Mochi.

Theo [Render Web Services](https://render.com/docs/web-services), web service cần nghe `0.0.0.0` và cổng được cấu hình. File startup đã xử lý phần này. Render kết thúc HTTPS phía trước container; ứng dụng giữ cookie Secure trong profile prod.

Nếu cần dữ liệu RAG/Support bền vững sau này, chuyển sang service có [persistent disk](https://render.com/docs/disks), gắn volume và đặt `AI_RAG_DB_PATH` tới file trên volume mà user container UID 10001 có quyền ghi. Không scale nhiều instance dùng chung một SQLite file. Nhập dữ liệu hiện có bằng backup SQLite phù hợp; image không đóng gói database Support local.

## 3. Chạy Docker local trước khi deploy

Từ thư mục `Homestay` trong PowerShell:

```powershell
Copy-Item .env.docker.example .env.docker
# Mở .env.docker và điền DB_PASSWORD, OPENROUTER_API_KEY của máy bạn.
docker compose up --build -d
docker compose logs -f homestay
```

Mở `http://localhost:8080`. SQL Server local cần bật TCP và cho phép kết nối từ Docker. `host.docker.internal` phù hợp Docker Desktop; trên Linux hãy cấu hình hostname/IP database mà container truy cập được. Nếu backend đang chạy trực tiếp ở 8080, dừng bản local đó hoặc đổi phía cổng host trong compose sang `127.0.0.1:8081:8080`.

```powershell
docker compose ps
docker compose down
```

Named volume `rag-data` giữ SQLite của bản Docker local. `down` không xóa volume; đừng dùng `down -v` nếu còn dữ liệu cần giữ. Cấu hình local dùng profile dev, cookie HTTP và tin chứng chỉ SQL local; không dùng cấu hình này thay bản prod HTTPS trên cloud.

## Vercel và Qdrant

- **Vercel:** Bản demo hiện dùng `vercel.json` làm gateway chuyển tiếp website tới Render bằng [external rewrites](https://vercel.com/docs/routing/rewrites). Java, Python RAG và frontend vẫn chạy chung trên Render. Chuyển hướng `/` sang `/pages/landing.html`; tắt cache rewrite để phiên đăng nhập và nội dung riêng không bị CDN lưu lại. Cấu hình này giữ đường dẫn API cùng origin và giữ kiểm tra quyền truy cập HTML của Java. Vercel không giữ API key hay mật khẩu SQL.
- **Qdrant:** Lưu và tìm vector cho RAG, cần thêm mô hình embedding, đồng bộ tài liệu và truy vấn tương ứng. Nó không thay thế các bảng quan hệ của ứng dụng. Bản deploy này tiếp tục dùng truy xuất từ khóa đã kiểm thử, không nhận một cấu hình Qdrant giả chưa được sử dụng.

## Kiểm tra và giới hạn của gói này

- Java được build thành executable Spring Boot JAR cùng frontend và asset AI.
- Kiểm thử bootstrap xác minh nạp đủ 101 tài liệu, không ghi đè admin sửa/gỡ, xử lý PORT và đường dẫn lưu trữ.
- Có kiểm tra cú pháp Compose và YAML Blueprint. Docker Engine trên phiên công cụ hiện từ chối quyền truy cập nên chưa build/chạy image thật ở đây; chạy lệnh local ở trên hoặc xem log build trên Render để xác minh image.
- Đã deploy thực tế bằng tài khoản của người dùng ngày 02/11/2026: [website Vercel](https://homestay-mochi-demo.vercel.app), [origin Render](https://homestay-mochi-demo.onrender.com). Somee có schema 7 bảng, 24 phòng và 17 dịch vụ trình bày; không sao chép khách hàng hoặc booking local. Tài khoản quản trị cloud mới dùng mật khẩu ngẫu nhiên riêng.
- Somee cấp alias database nhưng chứng chỉ SQL ghi tên máy chủ `vb4300.mgmt.somee.com`. Console Somee xác nhận MachineName `vb4300`; bản live dùng hostname này, vẫn giữ `DB_ENCRYPT=true` và `DB_TRUST_SERVER_CERTIFICATE=false`. Nếu chuyển database sang máy chủ khác, kiểm tra lại tên máy chủ/chứng chỉ, không tắt xác minh TLS.

## Nhánh triển khai qua trình duyệt

Nhánh `deploy/free-demo-20261102` trên GitHub có `deployment-source.tar.gz`, `deployment-manifest.json` và `Dockerfile.render`. Render build độc lập từ mã nguồn trong archive; các thư mục mã nguồn thông thường trên nhánh đó có thể cũ hơn archive. Nhánh làm việc local vẫn giữ các thay đổi hiện tại để tiếp tục phát triển.

Tệp đóng gói và biên bản nằm ngoài repo tại `D:\Thuctap\Luu_tru_kiem_tra\Docker_Render_20261102`. Khi cập nhật mã nguồn, chạy lại `package_deploy.py`, kiểm tra manifest/secret scan rồi đưa archive, manifest và Dockerfile tương ứng lên nhánh deployment trước khi deploy Render. `vercel.json` ở root repo chỉ quản lý gateway, không đóng gói bí mật.

Không đưa `TAI_KHOAN_DEMO.txt`, `cloud-login.private.json`, `somee-admin.private.sql` hoặc bất kỳ `.env` thật nào lên GitHub.
# Cập nhật giá gói theo giờ 03/11/2026

Khi ứng dụng khởi động, migration bổ sung các cột giá gói 2/4/8 giờ cho Rooms
và bản chụp giá gói cho Bookings trong một giao dịch có khóa migration. Chỉ lần
đầu tạo các cột này mới nạp giá từ 13 poster cho đúng mã Pxxx/DEMO-Pxxx tương ứng:
250.000/2 giờ, 350.000/4 giờ, 550.000/8 giờ và 80.000/giờ lẻ. Các lần khởi động
sau giữ nguyên chỉnh sửa của admin. Giá đêm và các booking/hóa đơn cũ không đổi.
Mã SQL thực thi nằm trong `HourlyPricingMigration.java`; tài khoản SQL cần quyền
ALTER TABLE. Readiness chỉ thành công sau khi migration hoàn tất.

