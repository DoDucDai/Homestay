let exploreRooms=[];
function explorePhoto(room, gallery=false) {
    const illustration=RoomPhotos.create(room,{gallery});
    if(illustration)return illustration;
    const photo=textNode('div','','explore-photo');
    const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');svg.setAttribute('viewBox','0 0 24 24');svg.setAttribute('aria-hidden','true');
    const use=document.createElementNS('http://www.w3.org/2000/svg','use');use.setAttribute('href','../css/icons.svg#bed');svg.append(use);
    photo.append(svg,textNode('strong',room.roomCode),textNode('small','Hình ảnh phòng đang được cập nhật'));
    return photo;
}
function exploreLink(room) {return 'explore.html?room='+encodeURIComponent(room.roomId);}
function exploreMoney(amount) { return Number(amount).toLocaleString('vi-VN')+' ₫'; }
function exploreRate(label,amount,unit,description='',tone='') {
    const card=textNode('div','','explore-rate-card'+(tone?' '+tone:''));
    const value=textNode('dd','','explore-rate-value');
    value.append(textNode('strong',exploreMoney(amount)),textNode('span',unit,'explore-rate-unit'));
    if(description)value.append(textNode('small',description,'explore-rate-caption'));
    card.append(textNode('dt',label,'explore-rate-label'),value);return card;
}
function exploreWeekendLabel(days) {
    const names=['','Thứ Hai','Thứ Ba','Thứ Tư','Thứ Năm','Thứ Sáu','Thứ Bảy','Chủ nhật'];
    return days.map(day=>names[day]).join(' & ');
}
function renderExploreRates(room) {
    const night=document.getElementById('explore-night-price');night.replaceChildren();
    if(room.nightlyPricing) {
        const days=room.nightlyPricing.weekendDays;
        night.append(exploreRate('Ngày thường',room.price,'/ đêm',days.join(',')==='6,7'?'Thứ Hai – thứ Sáu':'Các đêm còn lại','explore-rate-weekday'),
            exploreRate('Cuối tuần',room.nightlyPricing.weekendPrice,'/ đêm',exploreWeekendLabel(days),'explore-rate-weekend'));
    } else night.append(exploreRate('Giá qua đêm',room.price,'/ đêm','','explore-rate-weekday'));
    const hour=document.getElementById('explore-hour-price'),extra=document.getElementById('explore-extra-hour'),rule=document.getElementById('explore-hour-rule');
    hour.replaceChildren();extra.hidden=true;rule.hidden=true;
    if(room.hourlyPackages) {
        for(const [hours,key] of [[2,'twoHours'],[4,'fourHours'],[8,'eightHours']])hour.append(exploreRate(hours+' giờ',room.hourlyPackages[key],'/ gói'));
        extra.replaceChildren(textNode('span','Giờ lẻ ngoài gói'),textNode('strong',exploreMoney(room.hourlyPrice)+' / giờ'));extra.hidden=false;
        rule.textContent='Tối thiểu gói 2 giờ · Làm tròn lên từng giờ. Tự áp dụng gói có tổng tiền thấp nhất.';rule.hidden=false;
    } else if(Number(room.hourlyPrice)>0)hour.append(exploreRate('Giá theo giờ',room.hourlyPrice,'/ giờ'));
    else hour.textContent='Chưa có giá theo giờ';
}
function exploreCardPricing(room) {
    const prices=textNode('div','','explore-card-pricing');
    for(const [label,amount] of room.nightlyPricing?[['Đêm ngày thường',room.price],['Đêm cuối tuần',room.nightlyPricing.weekendPrice]]:[['Qua đêm',room.price]]) {
        const row=textNode('p','','explore-card-rate');row.append(textNode('span',label),textNode('strong',exploreMoney(amount)));prices.append(row);
    }
    const hour=room.hourlyPackages?exploreMoney(room.hourlyPackages.twoHours)+' / 2 giờ':Number(room.hourlyPrice)>0?exploreMoney(room.hourlyPrice)+' / giờ':'Chưa có giá giờ';
    prices.append(textNode('p','Theo giờ · '+hour,'explore-card-hour'));return prices;
}
function filterExploreRooms(rows,search,type,sort) {
    const query=search.trim().toLocaleLowerCase('vi');
    return rows.filter(room=>(!type || room.roomType===type) && (!query || [room.roomCode,room.roomName].some(value=>value.toLocaleLowerCase('vi').includes(query))))
        .sort((a,b)=>sort==='price-up'?Number(a.price)-Number(b.price):sort==='price-down'?Number(b.price)-Number(a.price):a.roomCode.localeCompare(b.roomCode,'vi',{numeric:true}));
}
function renderExploreRooms() {
    const rows=filterExploreRooms(exploreRooms,document.getElementById('explore-search').value,document.getElementById('explore-type').value,document.getElementById('explore-sort').value);
    const grid=document.getElementById('explore-grid');grid.replaceChildren();
    document.getElementById('explore-count').textContent=rows.length+' phòng phù hợp · Xem chi tiết trước khi chọn thời gian lưu trú';
    if(!rows.length) {grid.append(textNode('p','Không tìm thấy phòng phù hợp. Hãy thử từ khóa hoặc loại phòng khác.','explore-empty'));return;}
    for(const room of rows) {
        const card=textNode('article','','explore-room-card'),copy=textNode('div','','explore-room-copy');
        const title=textNode('h2',''),name=textNode('a',room.roomName);name.href=exploreLink(room);title.append(name);
        const link=textNode('a','Xem chi tiết →','explore-room-link');link.href=exploreLink(room);link.setAttribute('aria-label','Xem chi tiết '+room.roomName);
        copy.append(textNode('p',room.roomType+' · '+room.roomCode,'explore-eyebrow'),title,
            textNode('p',room.description||'Thông tin mô tả phòng đang được cập nhật.','explore-description'),
            exploreCardPricing(room),link);
        card.append(explorePhoto(room),copy);grid.append(card);
    }
}
function renderExploreDetail(room) {
    document.title=room.roomName+' — Homestay';
    document.getElementById('explore-room-title').textContent=room.roomName;
    document.getElementById('explore-room-type').textContent=room.roomType;
    document.getElementById('explore-room-code').textContent='Mã phòng · '+room.roomCode;
    document.getElementById('explore-room-description').textContent=room.description||'Thông tin mô tả phòng đang được cập nhật.';
    renderExploreRates(room);
    document.getElementById('explore-detail-photo').replaceChildren(explorePhoto(room,true));
    document.getElementById('explore-book-link').href='bookings.html?'+new URLSearchParams({type:room.roomType,room:room.roomCode});
}
async function loadExplore() {
    const id=new URLSearchParams(window.location.search).get('room');
    document.getElementById('explore-error').hidden=true;
    document.getElementById('explore-list-view').hidden=!!id;
    document.getElementById('explore-detail-view').hidden=true;
    try {
        if(id && (!/^[1-9][0-9]*$/.test(id)||!Number.isSafeInteger(Number(id)))) throw new Error('Mã phòng không hợp lệ.');
        const response=await fetch('/api/public/rooms'+(id?'/'+encodeURIComponent(id):''),{cache:'no-store'});
        const data=await responseJson(response);
        if(id) {renderExploreDetail(data);document.getElementById('explore-detail-view').hidden=false;}
        else {
            exploreRooms=expectList(data);
            const select=document.getElementById('explore-type'),selected=select.value;
            select.replaceChildren(selectOption('','Tất cả loại phòng'));
            [...new Set(exploreRooms.map(room=>room.roomType))].sort().forEach(type=>select.append(selectOption(type,type)));
            select.value=selected;renderExploreRooms();
        }
    } catch(error) {
        document.getElementById('explore-list-view').hidden=true;
        document.getElementById('explore-error-message').textContent=error.message||'Không tải được danh mục phòng.';
        document.getElementById('explore-error').hidden=false;
    }
}
document.addEventListener('DOMContentLoaded',async()=>{
    document.getElementById('explore-filters').addEventListener('submit',event=>event.preventDefault());
    for(const id of ['explore-search','explore-type','explore-sort'])document.getElementById(id).addEventListener('input',renderExploreRooms);
    document.getElementById('explore-retry').addEventListener('click',loadExplore);
    loadExplore();
    const user=await checkLogin();
    renderPublicAccount(document.getElementById('explore-account'),user);
    window.addEventListener('pageshow',event=>{if(event.persisted)window.location.reload();});
});
